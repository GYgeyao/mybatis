package com.geyao.mybatis.mapper;


import java.util.List;

import com.geyao.mybatis.pojo.Blog;

public interface BlogMapper {
	Blog selectBlogById(Integer id);
	
	List<Blog> selectBlogList();
	
	
	List<Blog> selectBlogListNested();
	Blog selectBlogByIdConstructor(Integer id);
}
