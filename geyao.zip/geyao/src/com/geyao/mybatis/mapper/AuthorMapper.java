package com.geyao.mybatis.mapper;

import com.geyao.mybatis.pojo.Author;
public interface AuthorMapper {
	Author selectAuthorById(Integer id);
}
