package com.geyao.mybatis.mapper;

import com.geyao.mybatis.pojo.Vehicle;

public interface VehicleMapper {
	Vehicle selectVehicleById(Integer id);
}
