package com.geyao.mybatis.mapper;

import java.util.List;

import com.geyao.mybatis.pojo.Comment;

public interface CommentMapper {
List<Comment> selectCommentByPostId(Integer id);
}
