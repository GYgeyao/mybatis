package com.geyao.mybatis.mapper;

import com.geyao.mybatis.pojo.Post;

public interface PostMapper {
	Post selectPostById(Integer id);
}
