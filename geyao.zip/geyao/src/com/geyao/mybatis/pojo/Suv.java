package com.geyao.mybatis.pojo;

public class Suv extends Vehicle {
	private Boolean allWheelDrive;
	public Suv() {
		
	}
	public Boolean getAllWheelDrive() {
		return allWheelDrive;
	}
	public void setAllWheelDrive(Boolean allWheelDrive) {
		this.allWheelDrive = allWheelDrive;
	}
	@Override
	public String toString() {
		return "Suv [allWheelDrive=" + allWheelDrive + "]";
	}
	
}
