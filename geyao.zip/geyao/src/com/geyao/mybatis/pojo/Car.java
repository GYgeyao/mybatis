package com.geyao.mybatis.pojo;

public class Car extends Vehicle {
	private Integer doorCount;
	
	public Car() {}

	public Integer getDoorCount() {
		return doorCount;
	}

	public void setDoorCount(Integer doorCount) {
		this.doorCount = doorCount;
	}
	
	
}
