package com.geyao.mybatis.pojo;

public class Author {
	private Integer id;
	private String username;
	private String password;
	private String email;
	private String bio;
	private String favouriteSection;
	private String nickname;
	private String realname;
	public Author() {
		super();
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getBio() {
		return bio;
	}
	public void setBio(String bio) {
		this.bio = bio;
	}
	public String getFavouriteSection() {
		return favouriteSection;
	}
	public void setFavouriteSection(String favouriteSection) {
		this.favouriteSection = favouriteSection;
	}
	public String getNickname() {
		return nickname;
	}
	public void setNickname(String nickname) {
		this.nickname = nickname;
	}
	public String getRealname() {
		return realname;
	}
	public void setRealname(String realname) {
		this.realname = realname;
	}
	public Author(Integer id, String username, String password, String email, String bio, String favouriteSection,
			String nickname, String realname) {
		super();
		this.id = id;
		this.username = username;
		this.password = password;
		this.email = email;
		this.bio = bio;
		this.favouriteSection = favouriteSection;
		this.nickname = nickname;
		this.realname = realname;
	}
	@Override
	public String toString() {
		return "Author [id=" + id + ", username=" + username + ", password=" + password + ", email=" + email + ", bio="
				+ bio + ", favouriteSection=" + favouriteSection + ", nickname=" + nickname + ", realname=" + realname
				+ "]";
	}
	
	
	
}
