package com.geyao.mybatis.mapper;


import org.apache.ibatis.session.SqlSession;
import org.junit.Test;


import com.geyao.mybatis.pojo.Car;
import com.geyao.mybatis.pojo.Suv;
import com.geyao.mybatis.util.MyBatisUtil;

public class VehicleMapperTest {
	@Test
	public void testselectVehicleById() {
		SqlSession session =MyBatisUtil.getSqlSession();
		 VehicleMapper vehicleMapper =session.getMapper(VehicleMapper.class);

		 Car vehicle1=(Car)vehicleMapper.selectVehicleById(1);
		 Suv vehicle3=(Suv)vehicleMapper.selectVehicleById(3);
		session.close();
		System.out.println(vehicle1);
		System.out.println(vehicle3);
	}
}
