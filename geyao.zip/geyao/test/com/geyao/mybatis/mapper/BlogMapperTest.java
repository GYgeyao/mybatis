package com.geyao.mybatis.mapper;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.junit.Test;

import com.geyao.mybatis.pojo.Author;
import com.geyao.mybatis.pojo.Blog;
import com.geyao.mybatis.pojo.Post;
import com.geyao.mybatis.util.MyBatisUtil;

public class BlogMapperTest {
	
	@Test
	public void testselectBlogListNested() {
		SqlSession session =MyBatisUtil.getSqlSession();
		BlogMapper blogMapper =session.getMapper(BlogMapper.class);
		
		List<Blog> biogList = blogMapper.selectBlogListNested();
		session.close();
		System.out.println(biogList);
	}
	@Test
	public void testselectBlogByIdConstructor() {
		SqlSession session =MyBatisUtil.getSqlSession();
		BlogMapper blogMapper =session.getMapper(BlogMapper.class);
		
		Blog biog = blogMapper.selectBlogByIdConstructor(1);
		session.close();
		System.out.println(biog);
	}

	@Test
	public void testselectBlogByIdLazyLoading() {
		SqlSession session =MyBatisUtil.getSqlSession();
		BlogMapper blogMapper =session.getMapper(BlogMapper.class);
		System.out.println("��ѯblog");
		Blog biog = blogMapper.selectBlogById(1);
		
		session.close();
		System.out.println("��ѯblog��title");
		System.out.println(biog.getTitle());
		System.out.println("��ѯauthor����");
		System.out.println(biog.getAuthor().getUsername());
		System.out.println("����");
	}
}
